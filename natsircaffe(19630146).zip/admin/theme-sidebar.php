        <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="deznav">
            <div class="deznav-scroll">
				<ul class="metismenu" id="menu">
                    <li><a href="index.php" class="ai-icon" aria-expanded="false">
							<i class="flaticon-381-settings-2"></i>
							<span class="nav-text">Produk</span>
						</a>
					</li>
                    <li><a href="keranjang.php" class="ai-icon" aria-expanded="false">
							<i class="flaticon-381-settings-2"></i>
							<span class="nav-text">Keranjang</span>
						</a>
                    </li>
                    <li><a href="transaksi.php" class="ai-icon" aria-expanded="false">
							<i class="flaticon-381-settings-2"></i>
							<span class="nav-text">Transaksi</span>
						</a>
                    </li>
                </ul>
				<div class="copyright">
					<p>Copyright &copy; Natsir 2023</p>
				</div>
			</div>
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->