        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright &copy; Natsir 2023</p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->