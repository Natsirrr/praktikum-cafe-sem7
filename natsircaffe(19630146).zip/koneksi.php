<?php

$conn = mysqli_connect("localhost", "root", "", "sircafe_db");

date_default_timezone_set("Asia/Singapore");
